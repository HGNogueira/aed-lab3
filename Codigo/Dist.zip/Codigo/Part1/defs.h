/******************************************************************************
 *
 * File Name: defs.h
 *	      (c) 2012 AED
 * Authors:    AED Team
 * Revision:  v2.3
 *
 *****************************************************************************/

#ifndef _DEFS_H_
#define _DEFS_H_

typedef void *Item;

#endif
